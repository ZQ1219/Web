package BBS;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

public class Page {
	public List<Article> articles=new ArrayList<Article>();
	public int curPage=1;
	public int allPage;
	public int artPerPage=20;
	private Connection conn=DB.getCon();
	public Page() {
	}
	public Page(int artPerPage) {
		this.artPerPage=artPerPage;
	}
	public void setArticles(List<Article> a) {
		this.articles=a;
		this.allPage=(articles.size()+artPerPage-1)/artPerPage;
	}
	public List<Article> getPage(int page){
		List<Article> ret=new ArrayList<Article>();
		for(int i=(page-1)*artPerPage;i<artPerPage*page&&i<articles.size();i++) {
			Article a=articles.get(i);
			ret.add(a);
		}
		return ret;
	}
}
