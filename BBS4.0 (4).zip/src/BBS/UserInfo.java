package BBS;

public class UserInfo {

	private String account;
	private String password;
	private String img;
	private String uid;
	public String getAccount() {
		return account;
	}
	public void setAccount(String netname) {
		this.account = netname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String code) {
		this.password = code;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}

	

}
