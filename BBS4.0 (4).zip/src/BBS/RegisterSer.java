package BBS;

import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/WebContent/RegisterSer")
public class RegisterSer extends HttpServlet {
	
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;character=utf-8");
		String account=request.getParameter("account");
		String password=request.getParameter("password");
		UserInfo mb=new UserInfo();
		mb.setAccount(account);
		mb.setPassword(password);
		HttpSession session=request.getSession();
		Register rs=new Register();
		rs.register(mb);
		response.sendRedirect("../../WebContent/index.jsp");
		
	}

}
