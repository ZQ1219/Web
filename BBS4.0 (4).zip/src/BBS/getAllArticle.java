package BBS;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public class getAllArticle {
	  public void tree(List<Article> articles) { 
		 Connection conn=DB.getCon();
		 String sql="select * from article where pid=0";
		Statement stmt=DB.createStmt(conn);
		ResultSet rs=DB.executeQuery(stmt, sql);
		try{
			while(rs.next()){
				Article a=new Article();
				a.setId(rs.getInt("id"));
				a.setPid(rs.getInt("pid"));
				a.setRootId(rs.getInt("rootid"));
				a.setTitle(rs.getString("title"));
				a.setLeaf(rs.getInt("isleaf")==0?true:false);
				a.setPdate(rs.getDate("pdate"));
				a.setAuthor(rs.getString("author"));
				a.setGrade(rs.getInt("grade"));
				articles.add(a);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		finally {
			DB.close(conn);
		}
		
	}
}
