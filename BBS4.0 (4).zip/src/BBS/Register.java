package BBS;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Register {
	Connection conn=DB.getCon();
	public void register(UserInfo mb) {
		String sql="insert into Member values(?,?,?)";
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, mb.getAccount());
			pst.setString(2, mb.getPassword());
			pst.setString(3, mb.getUid());
		}catch(SQLException e) {
			e.printStackTrace();
			
		}
	}
	
}
